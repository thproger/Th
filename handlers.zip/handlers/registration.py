from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import db
from config import ROLE_LABELS
from permissions import has_role, role_level, ROLE_ADMIN, ROLE_GROUP_LEADER
from keyboards import (
    main_menu_keyboard,
    cancel_keyboard,
    roles_keyboard,
    users_list_keyboard,
    BTN_MANAGE_USERS,
    BTN_CANCEL,
)
from utils import format_user

router = Router()


class RegisterStates(StatesGroup):
    waiting_name = State()


WELCOME_NEW = """👋 <b>Вітаю в Task Manager Bot!</b>

Це бот для управління завданнями в команді.

Щоб почати, введи своє ім'я та прізвище для реєстрації."""

WELCOME_NO_ROLE = """👋 Ти вже зареєстрований, але роль ще не призначено.

⏳ Зачекай, поки адміністратор призначить роль.

<b>Команди:</b>
/start — оновити меню
/me — переглянути профіль"""

WELCOME_BACK = """👋 З поверненням, <b>{name}</b>!
Роль: {role}

<b>Команди:</b>
/me — переглянути профіль"""


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    user = await db.get_user(message.from_user.id)

    if user:
        role = user.get("role")
        if not role:
            await message.answer(WELCOME_NO_ROLE, parse_mode="HTML")
            return

        await message.answer(
            WELCOME_BACK.format(name=user["full_name"], role=ROLE_LABELS.get(role, role)),
            reply_markup=main_menu_keyboard(role),
            parse_mode="HTML",
        )
        return

    await message.answer(WELCOME_NEW, parse_mode="HTML")
    await message.answer("✏️ Введи своє ім'я та прізвище:", reply_markup=cancel_keyboard())
    await state.set_state(RegisterStates.waiting_name)


@router.message(RegisterStates.waiting_name, F.text == BTN_CANCEL)
async def cancel_register(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("❌ Реєстрацію скасовано.")


@router.message(RegisterStates.waiting_name)
async def process_name(message: Message, state: FSMContext):
    full_name = (message.text or "").strip()
    if len(full_name) < 2:
        await message.answer("Ім'я занадто коротке. Спробуй ще раз:")
        return

    await db.create_user(
        telegram_id=message.from_user.id,
        username=message.from_user.username,
        full_name=full_name,
    )
    await state.clear()
    await message.answer(
        f"✅ Реєстрацію завершено!\nІм'я: <b>{full_name}</b>\n\n"
        "⏳ Зачекай, поки адміністратор призначить тобі роль.",
        parse_mode="HTML",
    )


@router.message(Command("me"))
async def cmd_me(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user:
        await message.answer("Ти ще не зареєстрований. Введи /start")
        return
    await message.answer(format_user(user), parse_mode="HTML")


@router.message(F.text == BTN_MANAGE_USERS)
async def admin_manage_users(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user or not has_role(user.get("role"), ROLE_ADMIN):
        await message.answer("❌ Немає доступу.")
        return

    users = await db.get_all_users()
    if not users:
        await message.answer("Користувачів ще немає.")
        return

    await message.answer(
        f"👥 Всього користувачів: {len(users)}\nОберіть користувача для призначення ролі:",
        reply_markup=users_list_keyboard(users, "admin_set_role"),
    )


@router.callback_query(F.data.startswith("admin_set_role:"))
async def admin_select_role(callback: CallbackQuery, state: FSMContext):
    admin = await db.get_user(callback.from_user.id)
    if not admin or not has_role(admin.get("role"), ROLE_ADMIN):
        await callback.answer("❌ Немає доступу.", show_alert=True)
        return

    target_id = int(callback.data.split(":")[1])
    target = await db.get_user(target_id)
    if not target:
        await callback.answer("Користувача не знайдено.", show_alert=True)
        return

    await state.update_data(target_id=target_id)
    name = target.get("full_name") or target.get("username") or str(target_id)
    await callback.message.edit_text(
        f"Оберіть роль для <b>{name}</b>:",
        reply_markup=roles_keyboard(),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("set_role:"))
async def set_role_handler(callback: CallbackQuery, state: FSMContext):
    admin = await db.get_user(callback.from_user.id)
    if not admin or not has_role(admin.get("role"), ROLE_ADMIN):
        await callback.answer("❌ Немає доступу.", show_alert=True)
        return

    data = await state.get_data()
    target_id = data.get("target_id")
    if not target_id:
        await callback.answer("Помилка стану.", show_alert=True)
        return

    role = callback.data.split(":")[1]
    await db.update_user_role(target_id, role)

    if role_level(role) == role_level(ROLE_GROUP_LEADER):
        existing = await db.get_group_by_leader(target_id)
        if not existing:
            target = await db.get_user(target_id)
            gname = f"Група {target.get('full_name', target_id)}"
            await db.create_group(target_id, gname)

    await state.clear()
    role_label = ROLE_LABELS.get(role, role)
    await callback.message.edit_text(f"✅ Роль <b>{role_label}</b> призначено!", parse_mode="HTML")

    try:
        await callback.bot.send_message(
            target_id,
            f"🎉 Тобі призначено роль: <b>{role_label}</b>\nНатисни /start для оновлення меню.",
            parse_mode="HTML",
        )
    except Exception:
        pass
